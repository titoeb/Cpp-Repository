To compile the project:
g++ *.cpp -o hex

To start:
./hex