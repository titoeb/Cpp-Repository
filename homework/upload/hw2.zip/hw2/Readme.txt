To compile the project:
g++ *.cpp -o hex -lpthread

To start:
./hex