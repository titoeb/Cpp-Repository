#include<iostream>
#include "play_hex.h"
using namespace std;

int main(){
    play_hex();
    //bot_play();
}

